﻿namespace DinhThienNhan_22112793_Assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_top = new System.Windows.Forms.Panel();
            this.pnl_gray = new System.Windows.Forms.Panel();
            this.pnl_back1 = new System.Windows.Forms.Panel();
            this.pnl_red = new System.Windows.Forms.Panel();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.pnl_back3 = new System.Windows.Forms.Panel();
            this.pnl_green = new System.Windows.Forms.Panel();
            this.pnl_back2 = new System.Windows.Forms.Panel();
            this.pnl_yellow = new System.Windows.Forms.Panel();
            this.btn_start = new System.Windows.Forms.Button();
            this.pnl_gray_2 = new System.Windows.Forms.Panel();
            this.btn_reset_2 = new System.Windows.Forms.Button();
            this.btn_stop_2 = new System.Windows.Forms.Button();
            this.btn_start_2 = new System.Windows.Forms.Button();
            this.pnl_gray_3 = new System.Windows.Forms.Panel();
            this.btn_reset_3 = new System.Windows.Forms.Button();
            this.btn_stop_3 = new System.Windows.Forms.Button();
            this.btn_start_3 = new System.Windows.Forms.Button();
            this.pnl_top.SuspendLayout();
            this.pnl_gray.SuspendLayout();
            this.pnl_back1.SuspendLayout();
            this.pnl_back3.SuspendLayout();
            this.pnl_back2.SuspendLayout();
            this.pnl_gray_2.SuspendLayout();
            this.pnl_gray_3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_top
            // 
            this.pnl_top.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnl_top.Controls.Add(this.pnl_gray_3);
            this.pnl_top.Controls.Add(this.pnl_gray_2);
            this.pnl_top.Controls.Add(this.pnl_gray);
            this.pnl_top.Location = new System.Drawing.Point(1, 0);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(1520, 441);
            this.pnl_top.TabIndex = 0;
            // 
            // pnl_gray
            // 
            this.pnl_gray.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnl_gray.Controls.Add(this.pnl_back1);
            this.pnl_gray.Controls.Add(this.btn_reset);
            this.pnl_gray.Controls.Add(this.btn_stop);
            this.pnl_gray.Controls.Add(this.btn_start);
            this.pnl_gray.Location = new System.Drawing.Point(54, 21);
            this.pnl_gray.Name = "pnl_gray";
            this.pnl_gray.Size = new System.Drawing.Size(375, 171);
            this.pnl_gray.TabIndex = 9;
            // 
            // pnl_back1
            // 
            this.pnl_back1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnl_back1.Controls.Add(this.pnl_red);
            this.pnl_back1.Location = new System.Drawing.Point(86, 31);
            this.pnl_back1.Name = "pnl_back1";
            this.pnl_back1.Size = new System.Drawing.Size(200, 106);
            this.pnl_back1.TabIndex = 0;
            // 
            // pnl_red
            // 
            this.pnl_red.BackColor = System.Drawing.Color.Red;
            this.pnl_red.Location = new System.Drawing.Point(41, 19);
            this.pnl_red.Name = "pnl_red";
            this.pnl_red.Size = new System.Drawing.Size(112, 72);
            this.pnl_red.TabIndex = 3;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_reset.ForeColor = System.Drawing.Color.Tomato;
            this.btn_reset.Location = new System.Drawing.Point(144, 143);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 5;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.Aqua;
            this.btn_stop.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_stop.Location = new System.Drawing.Point(292, 73);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(75, 34);
            this.btn_stop.TabIndex = 6;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = false;
            // 
            // pnl_back3
            // 
            this.pnl_back3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnl_back3.Controls.Add(this.pnl_green);
            this.pnl_back3.Location = new System.Drawing.Point(86, 21);
            this.pnl_back3.Name = "pnl_back3";
            this.pnl_back3.Size = new System.Drawing.Size(200, 106);
            this.pnl_back3.TabIndex = 8;
            // 
            // pnl_green
            // 
            this.pnl_green.BackColor = System.Drawing.Color.Lime;
            this.pnl_green.Location = new System.Drawing.Point(47, 19);
            this.pnl_green.Name = "pnl_green";
            this.pnl_green.Size = new System.Drawing.Size(112, 72);
            this.pnl_green.TabIndex = 2;
            // 
            // pnl_back2
            // 
            this.pnl_back2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnl_back2.Controls.Add(this.pnl_yellow);
            this.pnl_back2.Location = new System.Drawing.Point(86, 31);
            this.pnl_back2.Name = "pnl_back2";
            this.pnl_back2.Size = new System.Drawing.Size(200, 106);
            this.pnl_back2.TabIndex = 7;
            // 
            // pnl_yellow
            // 
            this.pnl_yellow.BackColor = System.Drawing.Color.Gold;
            this.pnl_yellow.Location = new System.Drawing.Point(44, 19);
            this.pnl_yellow.Name = "pnl_yellow";
            this.pnl_yellow.Size = new System.Drawing.Size(112, 72);
            this.pnl_yellow.TabIndex = 1;
            // 
            // btn_start
            // 
            this.btn_start.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_start.ForeColor = System.Drawing.Color.Indigo;
            this.btn_start.Location = new System.Drawing.Point(3, 73);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 34);
            this.btn_start.TabIndex = 4;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = false;
            this.btn_start.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnl_gray_2
            // 
            this.pnl_gray_2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnl_gray_2.Controls.Add(this.btn_reset_2);
            this.pnl_gray_2.Controls.Add(this.btn_stop_2);
            this.pnl_gray_2.Controls.Add(this.pnl_back2);
            this.pnl_gray_2.Controls.Add(this.btn_start_2);
            this.pnl_gray_2.Location = new System.Drawing.Point(475, 21);
            this.pnl_gray_2.Name = "pnl_gray_2";
            this.pnl_gray_2.Size = new System.Drawing.Size(381, 171);
            this.pnl_gray_2.TabIndex = 10;
            // 
            // btn_reset_2
            // 
            this.btn_reset_2.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_reset_2.ForeColor = System.Drawing.Color.Tomato;
            this.btn_reset_2.Location = new System.Drawing.Point(148, 143);
            this.btn_reset_2.Name = "btn_reset_2";
            this.btn_reset_2.Size = new System.Drawing.Size(75, 23);
            this.btn_reset_2.TabIndex = 5;
            this.btn_reset_2.Text = "Reset";
            this.btn_reset_2.UseVisualStyleBackColor = false;
            // 
            // btn_stop_2
            // 
            this.btn_stop_2.BackColor = System.Drawing.Color.Aqua;
            this.btn_stop_2.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_stop_2.Location = new System.Drawing.Point(292, 73);
            this.btn_stop_2.Name = "btn_stop_2";
            this.btn_stop_2.Size = new System.Drawing.Size(75, 34);
            this.btn_stop_2.TabIndex = 6;
            this.btn_stop_2.Text = "Stop";
            this.btn_stop_2.UseVisualStyleBackColor = false;
            // 
            // btn_start_2
            // 
            this.btn_start_2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_start_2.ForeColor = System.Drawing.Color.Indigo;
            this.btn_start_2.Location = new System.Drawing.Point(3, 73);
            this.btn_start_2.Name = "btn_start_2";
            this.btn_start_2.Size = new System.Drawing.Size(75, 34);
            this.btn_start_2.TabIndex = 4;
            this.btn_start_2.Text = "Start";
            this.btn_start_2.UseVisualStyleBackColor = false;
            // 
            // pnl_gray_3
            // 
            this.pnl_gray_3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pnl_gray_3.Controls.Add(this.btn_reset_3);
            this.pnl_gray_3.Controls.Add(this.btn_stop_3);
            this.pnl_gray_3.Controls.Add(this.btn_start_3);
            this.pnl_gray_3.Controls.Add(this.pnl_back3);
            this.pnl_gray_3.Location = new System.Drawing.Point(905, 21);
            this.pnl_gray_3.Name = "pnl_gray_3";
            this.pnl_gray_3.Size = new System.Drawing.Size(381, 171);
            this.pnl_gray_3.TabIndex = 11;
            // 
            // btn_reset_3
            // 
            this.btn_reset_3.BackColor = System.Drawing.Color.DarkBlue;
            this.btn_reset_3.ForeColor = System.Drawing.Color.Tomato;
            this.btn_reset_3.Location = new System.Drawing.Point(151, 143);
            this.btn_reset_3.Name = "btn_reset_3";
            this.btn_reset_3.Size = new System.Drawing.Size(75, 23);
            this.btn_reset_3.TabIndex = 5;
            this.btn_reset_3.Text = "Reset";
            this.btn_reset_3.UseVisualStyleBackColor = false;
            // 
            // btn_stop_3
            // 
            this.btn_stop_3.BackColor = System.Drawing.Color.Aqua;
            this.btn_stop_3.ForeColor = System.Drawing.Color.DarkRed;
            this.btn_stop_3.Location = new System.Drawing.Point(292, 73);
            this.btn_stop_3.Name = "btn_stop_3";
            this.btn_stop_3.Size = new System.Drawing.Size(75, 34);
            this.btn_stop_3.TabIndex = 6;
            this.btn_stop_3.Text = "Stop";
            this.btn_stop_3.UseVisualStyleBackColor = false;
            // 
            // btn_start_3
            // 
            this.btn_start_3.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_start_3.ForeColor = System.Drawing.Color.Indigo;
            this.btn_start_3.Location = new System.Drawing.Point(3, 73);
            this.btn_start_3.Name = "btn_start_3";
            this.btn_start_3.Size = new System.Drawing.Size(75, 34);
            this.btn_start_3.TabIndex = 4;
            this.btn_start_3.Text = "Start";
            this.btn_start_3.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1646, 610);
            this.Controls.Add(this.pnl_top);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_top.ResumeLayout(false);
            this.pnl_gray.ResumeLayout(false);
            this.pnl_back1.ResumeLayout(false);
            this.pnl_back3.ResumeLayout(false);
            this.pnl_back2.ResumeLayout(false);
            this.pnl_gray_2.ResumeLayout(false);
            this.pnl_gray_3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_top;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Panel pnl_back1;
        private System.Windows.Forms.Panel pnl_red;
        private System.Windows.Forms.Panel pnl_yellow;
        private System.Windows.Forms.Panel pnl_green;
        private System.Windows.Forms.Panel pnl_gray;
        private System.Windows.Forms.Panel pnl_back3;
        private System.Windows.Forms.Panel pnl_back2;
        private System.Windows.Forms.Panel pnl_gray_3;
        private System.Windows.Forms.Button btn_reset_3;
        private System.Windows.Forms.Button btn_stop_3;
        private System.Windows.Forms.Button btn_start_3;
        private System.Windows.Forms.Panel pnl_gray_2;
        private System.Windows.Forms.Button btn_reset_2;
        private System.Windows.Forms.Button btn_stop_2;
        private System.Windows.Forms.Button btn_start_2;
    }
}

